jQuery(document).ready(function() {
  console.log("yalasuo");
  jQuery("#slider").owlCarousel({
      items : 4,
      itemsDesktop : [1199,3],
      itemsDesktopSmall : [979,3],
  });
  
});